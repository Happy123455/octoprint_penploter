# OctoPrint-PlotterHandwriting

An OctoPrint plugin to generate organic, human-looking handwriting G-code for pen plotters, drawing machines, and 3D printers with pen mounts.

## Features

- Procedural handwriting humanization (baseline drift, size/spacing jitter, slanting variations, hand tremors, and pen drag hooks).
- Multi-font support (Cursive, Script Complex, Script Simplex, Futura Print).
- Live browser-based paper simulation and preview.
- Customizable G-code commands for travel and drawing (compatible with Z-axis, servos, and lasers).
- Direct upload to OctoPrint local folder.

## Installation

Install via the OctoPrint Plugin Manager or manually:

```bash
pip install .
```
